# GreenTech Mini Project

Bộ hồ sơ mô phỏng quản trị hạ tầng và nhật ký kỹ thuật.

- Tài liệu hướng dẫn: [`docs/README.md`](docs/README.md)
- SRS: [`docs/srs-he-thong.docx`](docs/srs-he-thong.docx)
- Script lọc log: [`scripts/auto_report.bat`](scripts/auto_report.bat)
- Bảng quản lý thiết bị: [`data/quan-ly-thiet-bi.xlsx`](data/quan-ly-thiet-bi.xlsx)
- Log mẫu: [`data/log-he-thong.log`](data/log-he-thong.log)

## Chạy nhanh
Mở Command Prompt tại thư mục gốc và chạy `scripts\auto_report.bat`.

Dữ liệu và cấu hình trong repository là dữ liệu giả lập; không dùng mật khẩu thật.
