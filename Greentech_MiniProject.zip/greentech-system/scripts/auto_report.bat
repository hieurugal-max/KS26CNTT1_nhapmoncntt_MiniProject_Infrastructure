@echo off
setlocal EnableExtensions
REM GreenTech - Audit and log report script
REM Run from the project root: scripts\auto_report.bat

set "ROOT=%~dp0.."
for %%I in ("%ROOT%") do set "ROOT=%%~fI"
set "LOG_FILE=%ROOT%\data\log-he-thong.log"
set "BACKUP_DIR=%ROOT%\backup"
set "REPORT=%BACKUP_DIR%\bao-cao-su-co.txt"

echo [AUDIT] GreenTech log report
if not exist "%LOG_FILE%" (
  echo [ERROR] Khong tim thay file log: "%LOG_FILE%"
  exit /b 1
)
if not exist "%BACKUP_DIR%\" (
  echo [AUDIT] Thu muc backup chua co, dang tao...
  mkdir "%BACKUP_DIR%"
  if errorlevel 1 (
    echo [ERROR] Khong tao duoc thu muc backup.
    exit /b 1
  )
)

echo [AUDIT] File log: "%LOG_FILE%"
echo [AUDIT] Bao cao: "%REPORT%"
echo [AUDIT] Chi doc log va ghi noi bao cao; khong xoa tep nao.
echo.>>"%REPORT%"
echo ==================================================>>"%REPORT%"
echo GreenTech - BAO CAO SU CO>>"%REPORT%"
echo Thoi diem chay: %DATE% %TIME%>>"%REPORT%"
echo Nguon: data\log-he-thong.log>>"%REPORT%"
echo ==================================================>>"%REPORT%"

REM Pipe + findstr streams matching lines without loading the whole file into a variable.
type "%LOG_FILE%" | findstr /I /C:"CRITICAL" /C:"ERROR" >> "%REPORT%"
if errorlevel 2 (
  echo [ERROR] Loi khi doc log hoac loc du lieu.
  exit /b 2
)

echo [OK] Da ghi noi ket qua vao "%REPORT%"
exit /b 0
