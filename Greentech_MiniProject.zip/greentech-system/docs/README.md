# GreenTech Infrastructure Management System

## 1. Mục đích
Dự án mô phỏng hệ thống quản trị hạ tầng cho startup GreenTech: tổ chức dữ liệu, lọc log sự cố, hướng dẫn vận hành và đối soát linh kiện cho các trạm cảm biến IoT.

## 2. Cấu trúc thư mục
```text
greentech-system/
├── docs/
│   ├── README.md
│   └── srs-he-thong.docx
├── scripts/
│   └── auto_report.bat
├── data/
│   ├── log-he-thong.log
│   └── quan-ly-thiet-bi.xlsx
├── backup/
│   └── bao-cao-su-co.txt
├── .env
└── .gitignore
```

## 3. Cách chạy script
Yêu cầu: Windows có `cmd.exe` và `findstr`.

1. Mở Terminal tại thư mục gốc dự án.
2. Chạy:
   ```bat
   scripts\auto_report.bat
   ```
3. Mở `backup\bao-cao-su-co.txt` để xem các dòng có `CRITICAL` hoặc `ERROR`.

Script chỉ đọc log và ghi nối báo cáo, không có lệnh xóa dữ liệu. Trước khi chạy, script kiểm tra file đầu vào và thư mục đầu ra.

## 4. Checklist kiểm tra thiết bị
- [ ] Kiểm tra mã trạm và mã linh kiện.
- [ ] Đối chiếu dung lượng RAM và loại lưu trữ.
- [ ] Xác nhận ngày lắp đặt.
- [ ] Kiểm tra log có lỗi CRITICAL hoặc ERROR.
- [ ] Sao lưu báo cáo sau khi kiểm tra.

## 5. Bảng thông số phần cứng mẫu

| Thiết bị | Thông số mẫu | Mục đích |
|---|---|---|
| CPU | ARM Cortex-A53 | Xử lý dữ liệu cảm biến |
| RAM | 4 GB | Chạy dịch vụ thu thập dữ liệu |
| SSD | 128 GB | Lưu dữ liệu cục bộ |
| Kết nối | Ethernet / Wi-Fi | Gửi dữ liệu về máy chủ |

## 6. Quy tắc xử lý dữ liệu
- Dùng mã linh kiện làm khóa để đối soát dữ liệu giữa hai bảng.
- Không chèn hàng trống hoặc gộp ô trong vùng dữ liệu Excel.
- Công thức tra cứu dùng `FALSE` để tìm chính xác và `TRIM` để loại bỏ khoảng trắng thừa.
- File `.env` trong bộ mẫu chỉ chứa cấu hình giả định, không dùng mật khẩu thật.

## 7. Ước tính thời gian tải log
Công thức: `MB/s = Mbps ÷ 8`; `Thời gian (giây) = Dung lượng (MB) ÷ Tốc độ (MB/s)`.
Ví dụ, tải 500 MB qua đường truyền 100 Mbps: tốc độ lý thuyết 12,5 MB/s, thời gian khoảng 40 giây, chưa tính hao hụt mạng.
